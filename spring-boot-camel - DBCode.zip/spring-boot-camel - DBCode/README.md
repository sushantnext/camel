# Getting started with Apache Camel and Spring Boot

Example code for using Spring Boot with Apache Camel

## Blog posts

Blog posts about this topic:

* [Working with Spring and Apache Camel](https://reflectoring.io/spring-camel/)


