package com.attra.camelapp;

import static org.junit.Assert.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.net.URL;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;

//@AutoConfigureMockMvc
//@ExtendWith(MockitoExtension.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class ProductControllerTest {

    // bind the above RANDOM_PORT
    @LocalServerPort
    private int port;
    
    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    public void getJMSTrue() throws Exception {

        
    	ResponseEntity<String> response = restTemplate.getForEntity(
			new URL("http://localhost:" + port + "/products/sendMessage/1").toString(), String.class);
    	if(response.getBody().contains("Success")) {
        assertEquals("Message Sent Successfully for id : 1", response.getBody());
    	}else {
    		assertNotEquals("Message Sent failed for id : 1", response.getBody());
    	}

    }
    
    @Test
    public void getJMSFalse() throws Exception {

        ResponseEntity<String> response = restTemplate.getForEntity(
			new URL("http://localhost:" + port + "/products/sendMessage/1").toString(), String.class);
        assertNotEquals("2", response.getBody());

    }
    
    @Test
    public void getKafkaTrue() throws Exception {

        ResponseEntity<String> response = restTemplate.getForEntity(
			new URL("http://localhost:" + port + "/products/sendMessageKafka/1").toString(), String.class);
        assertEquals("1", response.getBody());

    }
    
    @Test
    public void getKafkaFalse() throws Exception {

        ResponseEntity<String> response = restTemplate.getForEntity(
			new URL("http://localhost:" + port + "/products/sendMessageKafka/1").toString(), String.class);
        assertNotEquals("2", response.getBody());

    }

    
    

}

