package com.attra.camelapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CamelappApplicationTests {

	@Test
	void contextLoads() {
	}

}
