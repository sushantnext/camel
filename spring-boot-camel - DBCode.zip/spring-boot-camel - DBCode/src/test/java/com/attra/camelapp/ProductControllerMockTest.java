package com.attra.camelapp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import javax.jms.JMSException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;

import com.attra.camelapp.controller.ProductController;
import com.attra.camelapp.exception.BootCustomException;
import com.attra.camelapp.models.ResponseType;
import com.attra.camelapp.services.ProductService;

//@AutoConfigureMockMvc
@ExtendWith(MockitoExtension.class)
//@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class ProductControllerMockTest {

    // bind the above RANDOM_PORT
    @LocalServerPort
    private int port;
    
    ResponseType typ=new ResponseType("1");
    
    @Mock
    private ProductService productService;

    @InjectMocks
    private ProductController productController;

    @BeforeEach
    void setMockOutput() throws BootCustomException, JMSException, Exception {
        when(productService.sendMessage("1")).thenReturn(typ);
    }
    
    
    @Test
    public void shouldReturnOne() throws JMSException, Exception {
        ResponseEntity<?> response = productController.indexProduct("1");
        System.out.println("response ="+response.getBody());
        assertEquals(response.getBody(), "1");
    }


}

