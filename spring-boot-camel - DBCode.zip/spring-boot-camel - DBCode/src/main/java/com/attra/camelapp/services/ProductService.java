/**
 * 
 */
package com.attra.camelapp.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.attra.camelapp.CamelappApplication;
import com.attra.camelapp.exception.BootCustomException;
import com.attra.camelapp.models.Order;
import com.attra.camelapp.models.Product;
import com.attra.camelapp.models.ResponseType;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author pratikdas
 *
 */
@Component
public class ProductService {
	
	@Autowired
	private JmsTemplate jmsTemplate;
	
	@Autowired
	private KafkaTemplate<String,Object> kafkaTemplate1;
	
	public double getPrice(final String productName) {
		
		return 2.4;
		
	}
	
	public List<Order> generateOrder() {
		System.out.println("generating orders");
		
		List<Order> orderLines = new ArrayList<Order>();
		
	//	OrderLine orderLine = new OrderLine();
	//	orderLine.setProduct(new Product("Television", "Electronics"));
		
		//orderLines.add(orderLine);
		
	//	orderLine = new OrderLine();
	//	orderLine.setProduct(new Product("Washing Machine", "Household"));
		
	//	orderLines.add(orderLine);
		return orderLines;
	}
	
	public List<Product> fetchProductsByCategory(final String category) {
		System.out.println("fetching products of category "+category);
		
		List<Product> products = new ArrayList<Product>();
		
	//	products.add(new Product("Television","Electronics"));
	//	products.add(new Product("Washing Machine","Household"));
		List<Product> prodcat=products.stream()
		.filter(pr->pr.getProductCategory()
		.contains(category))
		.collect(Collectors.toList());
		
		return prodcat;
	}
	
	public List<Product> fetchProductsByName(final String name) {
		System.out.println("fetching products of category "+name);
		
		List<Product> products = new ArrayList<Product>();
		
	//	products.add(new Product("Television","Electronics"));
	//	products.add(new Product("Washing Machine","Household"));
		List<Product> prodcat=products.stream()
		.filter(pr->pr.getProductName()
		.contains(name))
		.collect(Collectors.toList());
		
		return prodcat;
	}
	
	    
	public ResponseType sendMessage(String id) throws BootCustomException {
	    	try {
	        Map<String, String> actionmap = new ConcurrentHashMap<>();
	        actionmap.put("id", id);
	        System.out.println("Sending the index request through queue message");
	        jmsTemplate.setMessageIdEnabled(true);
	        
	    //    jmsTemplate.setMessageTimestampEnabled(true);
	       // jmsTemplate.setPubSubDomain(true);
	        jmsTemplate.convertAndSend(CamelappApplication.PRODUCT_MESSAGE_QUEUE, new ObjectMapper().writeValueAsString(actionmap));
	        //throw new JMSException("Message Failed");
	    	}catch(Exception e) {
	    		//return new ResponseType(e.getMessage());
	    		e.printStackTrace();
	    		throw new BootCustomException("Message Sent failed for id : "+id);
	    		//return new ResponseType("Message Sent failed for id : "+id);
	    	}
	        return new ResponseType("Message Sent Successfully for id : "+id);
	    }
	    
	    public ResponseType sendMessageKafka(String id) throws BootCustomException {
	    	try {
	        Map<String, Object> actionmap = new HashMap<>();
	        actionmap.put("id", id);
	        System.out.println("Sending the index request through queue message");
	        System.out.println("test="+new ObjectMapper().writeValueAsString(actionmap));
	        kafkaTemplate1.send(CamelappApplication.PRODUCT_MESSAGE_TOPIC, new ObjectMapper().writeValueAsString(actionmap));
	        
	       // throw new CamelCustomException("Message Failed");
	    	}catch(Exception e) {
	    		e.printStackTrace();
	    		throw new BootCustomException("Exception occured");
	    		//return new ResponseType(e.getMessage());
	    	}
	        return new ResponseType("Kafka Message Sent Successfully for id : "+id);
	    }
	

}
