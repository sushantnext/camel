package com.attra.camelapp.repository;

import org.springframework.data.repository.CrudRepository;

import com.attra.camelapp.models.Order;

public interface OrderRepository extends CrudRepository<Order, Long> {
}
