/**
 * 
 */
package com.attra.camelapp.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

/**
 * @author sushantrane
 *
 */
@Component
public class FetchProductsRoute extends RouteBuilder {

	@Override
	public void configure() throws Exception {
	
		from("direct:fetchProducts").setHeader("category").body()
		  .routeId("direct-fetchProducts")
		  .tracing()
		  .log(">>> ${body}")
		  .to("bean:productService?method=fetchProductsByCategory(${header.category})").
		  end();
		
		from("direct:fetchProductsName").setHeader("name").body()
		  .routeId("direct-fetchProductsName")
		  .tracing()
		  .log(">>> ${body}")
		  .to("bean:productService?method=fetchProductsByName(${header.name})").
		  end();
		
		from("direct:genOrder")
		  .routeId("direct-genOrder")
		  .tracing()
		  .log(">>> ${body}")
		  .to("bean:orderService?method=generateOrder(${body})").
		  end();

	}

}
