package com.attra.camelapp.listener;

import java.util.concurrent.CountDownLatch;

import javax.jms.ExceptionListener;
import javax.jms.JMSException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class JmsExceptionListener implements ExceptionListener {
	
	private static final Logger log = LoggerFactory.getLogger(MessageListener.class);
    final CountDownLatch latch = new CountDownLatch(3);


	@Override
	public void onException(JMSException e)  {
		try {
		  latch.countDown();
		log.error("JmsExceptionListener handles error"+latch.getCount());
		}catch(Exception ex) {
		 // throw new Exception(ex.getMessage());	
		}
		//throw new BootCustomException(" JMS Exception");
	}
}
