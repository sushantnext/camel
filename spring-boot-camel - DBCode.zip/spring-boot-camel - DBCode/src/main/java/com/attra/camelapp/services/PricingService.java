/**
 * 
 */
package com.attra.camelapp.services;

import java.util.Set;
import java.util.function.Predicate;

import org.springframework.stereotype.Service;

import com.attra.camelapp.models.Order;
import com.attra.camelapp.models.Product;

/**
 * @author sushantrane
 *
 */
@Service
public class PricingService {
	
	public Order calculatePrice(final Order orderLine ) {
		Set<Product> categorys = orderLine.getOrderLines();
		
	//filter 1
    /*    Predicate<Product> electric = e -> e.getProductCategory() == EmployeeStatus.ACTIVE;
 
        //filter2
        Predicate<Employee> isAccountActive = e -> e.getAccount().getStatus() == AccountStatus.ACTIVE;
         
        //Active employees
        String result = employeeList.stream()
                .filter(isEmployeeActive)
                .map(e -> e.getId().toString())
                .collect(Collectors.joining(",", "[", "]"));
         
        System.out.println("Active employees = " + result);
         
		
		categorys.stream().filter(p->p.getProductCategory().equalsIgnoreCase("Electric") && p->p)
		.map(pp ->pp.getPrice()).setPrice(300.0))          // fetching price  
        .forEach(System.out::println);  // iterating price  
	/*		  orderLine.setPrice();
		else if("Household".equalsIgnoreCase(category))
			orderLine.setPrice(55.0);
		else
			orderLine.setPrice(99.0);
		}*/
		return orderLine;
		
	}

}
