package com.attra.camelapp.listener;

import javax.jms.JMSException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import com.attra.camelapp.models.Product;
import com.attra.camelapp.repository.ProductRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * This is the queue listener class, its receiveMessage() method ios invoked with the
 * message as the parameter.
 */
@Component
public class MessageListener {

	@Autowired
    private ProductRepository productRepository;

    private static final Logger log = LoggerFactory.getLogger(MessageListener.class);
    
/*    @Override
	public void onMessage(Message message) {
		if (message instanceof ActiveMQTextMessage) {
			ActiveMQTextMessage amqMessage = (ActiveMQTextMessage) message;
			try {
				String msg = String.format("QueueMessageConsumer Received message [ %s ]", amqMessage.getBody(Map.class));
				System.out.println(msg);
			} catch (JMSException e) {
				e.printStackTrace();
			}
		} else {
			System.out.println("QueueMessageConsumer Received non-text message");
		}
	}*/

   
    /**
     * This method is invoked whenever any new message is put in the queue.
     * See {@link v.springframework.SpringBootActiveMQApplication} for more details
     * @param message
     * @throws Exception 
     * @throws JsonMappingException 
     */
      @JmsListener(destination ="${spring.dynamq.queues}" ,containerFactory="jmsListenerContainerFactory")
      public void receive(@Payload String message) throws JMSException, JsonMappingException, Exception{
        log.info("Received <" + message + ">");
        Product product = new ObjectMapper().readValue(message, Product.class);
        log.info(" product id = "+product.getProductId());
    /*    Long id = Long.valueOf(message.get("id"));
        Product product = productRepository.findById(id).orElse(null);
        product.setMessageReceived(true);
        product.setMessageCount(product.getMessageCount() + 1);
        productRepository.save(product);*/
        log.info("Message processed...");
        
       // throw new CamelCustomException("Test  exception");
    }
    
    @KafkaListener(topics = "#{'${spring.kafka.topics}'.split(',')}",groupId="1",containerFactory = "kafkaListenerContainerFactory")
    public void receiveMessage(@Payload String message) {
        System.out.println("received payload='{}'"+ message);
      //  setPayload(consumerRecord.toString());
       // latch.countDown();
    	try {
    //    log.info("Received <" +new ObjectMapper().readString(message); ">");
    	}catch(Exception e) {
    		e.printStackTrace();
    	}

    

}

    
    
    
}
