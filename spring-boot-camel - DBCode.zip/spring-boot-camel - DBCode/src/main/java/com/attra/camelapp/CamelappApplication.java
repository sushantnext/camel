package com.attra.camelapp;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.component.servlet.CamelHttpTransportServlet;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.jms.annotation.EnableJms;

@SpringBootApplication
@EnableJms
//@EnableRetry
//@EnableKafka
public class CamelappApplication {

	public static final String PRODUCT_MESSAGE_QUEUE = "attra-activemq-queue";

	public static final String PRODUCT_MESSAGE_TOPIC = "sushant-topic1";

	private static final String camel_url_mapping = "/api/*";
	private static final String camel_servlet_name = "CamelServlet";

	public static void main(String[] args) {
		SpringApplication.run(CamelappApplication.class, args);
	}

	/*
	 * @Bean public JmsListenerContainerFactory<?> jmsFactory(ConnectionFactory
	 * connectionFactory, DefaultJmsListenerContainerFactoryConfigurer configurer) {
	 * DefaultJmsListenerContainerFactory factory = new
	 * DefaultJmsListenerContainerFactory(); // This provides all boot's default to
	 * this factory, including the message converter configurer.configure(factory,
	 * connectionFactory); // You could still override some of Boot's default if
	 * necessary. return factory; }
	 */

	@Bean
	public ServletRegistrationBean servletregistrationbean() {
		ServletRegistrationBean registration = new ServletRegistrationBean(new CamelHttpTransportServlet(),
				camel_url_mapping);
		registration.setName(camel_servlet_name);
		return registration;
	}

	@Bean
	public ServletRegistrationBean swaggerservlet() {
		ServletRegistrationBean swagger = new ServletRegistrationBean(new CamelHttpTransportServlet(), "/api-doc/*");
		Map<String, String> params = new HashMap();
		params.put("base.path", "api");
		params.put("api.title", "my api title");
		params.put("api.description", "my api description");
		params.put("api.termsofserviceurl", "termsofserviceurl");
		params.put("api.license", "license");
		params.put("api.licenseurl", "licenseurl");
		swagger.setInitParameters(params);
		return swagger;
	}

}
