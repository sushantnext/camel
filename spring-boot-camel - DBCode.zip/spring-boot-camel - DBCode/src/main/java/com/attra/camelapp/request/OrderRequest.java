/**
 * 
 */
package com.attra.camelapp.request;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import com.attra.camelapp.models.Product;

/**
 * @author pratikdas
 *
 */
public class OrderRequest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2310728166190042521L;

	private Long id;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

    private String orderNum;

    private String orderDate;
	
	private Set<Product> orderLines=new HashSet<Product>();
    private double totalDiscount;
	
	private double orderPrice;

	public String getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}


	public Set<Product> getOrderLines() {
		return orderLines;
	}

	public void setOrderLines(Set<Product> orderLines) {
		this.orderLines = orderLines;
	}


	public double getTotalDiscount() {
		return totalDiscount;
	}

	public void setTotalDiscount(double totalDiscount) {
		this.totalDiscount = totalDiscount;
	}

	public double getOrderPrice() {
		return orderPrice;
	}

	public void setOrderPrice(double orderPrice) {
		this.orderPrice = orderPrice;
	}

	/*public void addOrderLine(OrderLine orderLine) {
		if(orderLines == null) orderLines = new HashSet<OrderLine>();
		orderLines.add(orderLine);
	}*/
	

}
