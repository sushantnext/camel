/**
 * 
 */
package com.attra.camelapp.services;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

import org.apache.camel.AggregationStrategy;
import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

import com.attra.camelapp.models.Order;

@Component
public class PriceAggregationStrategy implements AggregationStrategy{
	
	@Override
	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
		Order newBody = newExchange.getIn().getBody(Order.class);
        if (oldExchange == null) {
            Order order = new Order();
            order.setOrderNum(UUID.randomUUID().toString());
            order.setOrderDate("28/01/2022");//Instant.now().toString());
            order.setOrderPrice(newBody.getOrderPrice());
            order.setOrderLines(newBody.getOrderLines());
                 
            newExchange.getIn().setBody(order, Order.class);
            return newExchange;
        }
        Order newOrderLine = newExchange.getIn().getBody(Order.class);
        Order order = oldExchange.getIn().getBody(Order.class);
        order.setOrderPrice(order.getOrderPrice() + newOrderLine.getOrderPrice());
        order.setOrderLines(newOrderLine.getOrderLines());
        oldExchange.getIn().setBody(order,Order.class);
        
        return oldExchange;
	}

}
