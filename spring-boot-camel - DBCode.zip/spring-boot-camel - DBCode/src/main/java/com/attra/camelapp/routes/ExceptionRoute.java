/**
 * 
 */
package com.attra.camelapp.routes;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import com.attra.camelapp.exception.BootCustomException;

/**
 * @author sushantrane
 *
 */
@Component
public class ExceptionRoute extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		onException(BootCustomException.class).process(new Processor() {

            public void process(Exchange exchange) throws Exception {
                System.out.println("handling ex");
              //  throw new CamelCustomException("test ex");
            }
        }).routeId("exception-route").log("Received body ").handled(true);

	}

}
