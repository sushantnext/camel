package com.attra.camelapp.config;

import javax.jms.DeliveryMode;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.support.QosSettings;
import org.springframework.stereotype.Component;
import org.springframework.util.backoff.FixedBackOff;

import com.attra.camelapp.DataUtils;
import com.attra.camelapp.listener.JmsExceptionListener;

@EnableJms
@Configuration
public class JMSConfig {
	
	@Value("${spring.activemq.broker-url}")
	private String broker_url;
	@Value("${spring.activemq.broker-username}")
	private String broker_username;
	@Value("${spring.activemq.broker-password}")
	private String broker_password;
	
	
	
	
	
	
		@Bean
		public ActiveMQConnectionFactory connectionFactory(){
		    ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory();
		    connectionFactory.setBrokerURL(broker_url);
		    connectionFactory.setPassword(broker_username);
		    connectionFactory.setUserName(broker_password);
		 //   connectionFactory.setExceptionListener(new JmsExceptionListener());
		    connectionFactory.setMaxThreadPoolSize(10);
		    connectionFactory.setAlwaysSyncSend(false);
		    connectionFactory.setUseAsyncSend(true);
		    return connectionFactory;
		}

		@Bean
		public JmsTemplate jmsTemplate(){
		    JmsTemplate template = new JmsTemplate();
		    
		    template.setConnectionFactory(connectionFactory());
		    return template;
		}

		@Bean
		public DefaultJmsListenerContainerFactory jmsListenerContainerFactory() throws Exception {
			FixedBackOff fbo = new FixedBackOff(); // or ExponentialBackOff
		    fbo.setMaxAttempts(1);
		    fbo.setInterval(5000);
		    DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
		    
		    QosSettings settings = new QosSettings();
		    settings.setDeliveryMode(DeliveryMode.PERSISTENT);
		    settings.setPriority(1);
		    settings.setTimeToLive(1000);
		    factory.setReplyPubSubDomain(true);
		    
		    factory.setReplyQosSettings(settings);
		    factory.setBackOff(fbo);
		    factory.setConnectionFactory(connectionFactory());
		    factory.setConcurrency("1-1");
		    factory.setRecoveryInterval(10000l);
		    return factory;
		}

	}


