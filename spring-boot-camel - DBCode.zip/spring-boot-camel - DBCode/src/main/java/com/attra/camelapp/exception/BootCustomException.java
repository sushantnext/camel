package com.attra.camelapp.exception;

public class BootCustomException extends RuntimeException{
	
    private static final long serialVersionUID = 1L;
    
        
    public BootCustomException(String msg) {
    	super(msg);
    }
    
    


}
