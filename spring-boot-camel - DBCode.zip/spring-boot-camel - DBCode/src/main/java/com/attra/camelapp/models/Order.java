/**
 * 
 */
package com.attra.camelapp.models;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

/**
 * @author pratikdas
 *
 */
@Entity
@Table(name = "Order1")
public class Order implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2310728166190042521L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "order_id", unique = true, nullable = false)
    private Long id;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

    @Column(name = "order_num", unique = true, nullable = false)
	private String orderNum;

    @Column(name = "order_date", unique = false, nullable = false)
    private String orderDate;
	
/*	@ManyToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	@JoinTable(
	  name = "order_line", 
	  joinColumns = @JoinColumn(name = "id"), 
	  inverseJoinColumns = @JoinColumn(name = "order_id"))*/
    @ManyToMany(cascade=CascadeType.MERGE)
    @JoinTable(name="order_line", joinColumns={@JoinColumn(referencedColumnName="order_id")}
                      , inverseJoinColumns={@JoinColumn(referencedColumnName="product_id")}) 
	private Set<Product> orderLines=new HashSet<Product>();
//	@OneToOne
	//@JoinColumn(name="id")
//	private OrderLine orderLine;
	
	
	
    @Column(name = "total_discount", unique = false, nullable = false, length = 100)
    private double totalDiscount;
	
    @Column(name = "order_price", unique = false, nullable = false, length = 100)
	private double orderPrice;

	public String getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}


	public Set<Product> getOrderLines() {
		return orderLines;
	}

	public void setOrderLines(Set<Product> orderLines) {
		this.orderLines = orderLines;
	}


	public double getTotalDiscount() {
		return totalDiscount;
	}

	public void setTotalDiscount(double totalDiscount) {
		this.totalDiscount = totalDiscount;
	}

	public double getOrderPrice() {
		return orderPrice;
	}

	public void setOrderPrice(double orderPrice) {
		this.orderPrice = orderPrice;
	}

	/*public void addOrderLine(OrderLine orderLine) {
		if(orderLines == null) orderLines = new HashSet<OrderLine>();
		orderLines.add(orderLine);
	}*/
	

}
