/**
 * 
 */
package com.attra.camelapp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.attra.camelapp.models.Order;
import com.attra.camelapp.models.Product;
import com.attra.camelapp.repository.OrderRepository;
import com.attra.camelapp.repository.ProductRepository;
import com.attra.camelapp.request.OrderRequest;
import com.fasterxml.jackson.core.JsonProcessingException;

/**
 * @author attra
 *
 */
@Service
public class OrderService {
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private OrderRepository orderRepository;
	
	public List<Product> getPrice(String productName) {
		
		return productRepository.findByName(productName);
		
	}
	
	public Order generateOrder(OrderRequest req) throws JsonProcessingException {
		System.out.println("generating orders");
		
		Order order= new Order();
		order.setOrderDate(req.getOrderDate());
		order.setOrderNum(req.getOrderNum());
		order.setOrderPrice(req.getOrderPrice());
		order.setTotalDiscount(req.getTotalDiscount());
		order.setOrderLines(req.getOrderLines());
		//order.setOrderLines(product);
		orderRepository.save(order);
		
		return order;
	}
	
	public List<Order> getOrders() {
		System.out.println("fetching orders");
		
		
		List<Order> orders=(List<Order>)orderRepository.findAll();
		
		return orders;
	}
	

}
