package com.attra.camelapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.attra.camelapp.models.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {

    List<Product> findByName(String name);

}
