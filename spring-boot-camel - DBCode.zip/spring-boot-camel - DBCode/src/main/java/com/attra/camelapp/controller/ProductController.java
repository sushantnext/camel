/**
 * 
 */
package com.attra.camelapp.controller;

import java.util.List;

import javax.jms.JMSException;

import org.apache.camel.ProducerTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.attra.camelapp.models.Order;
import com.attra.camelapp.models.Product;
import com.attra.camelapp.models.ResponseType;
import com.attra.camelapp.request.OrderRequest;
import com.attra.camelapp.services.OrderService;
import com.attra.camelapp.services.ProductService;
import com.fasterxml.jackson.core.JsonProcessingException;

/**
 * @author sushantrane
 *
 */
@RestController
public class ProductController {
	
    @Autowired
	private ProducerTemplate producerTemplate;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private OrderService orderService;
	
	
	
	@GetMapping("/productCat/{category}")
	public ResponseEntity<List<Product>> getProductsByCategory(@PathVariable("category") final String category){
		
		producerTemplate.start();
		@SuppressWarnings("unchecked")
		List<Product> products = producerTemplate.requestBody("direct:fetchProducts", category, List.class);
	    System.out.println("products "+products);
		producerTemplate.stop();
		return new ResponseEntity<List<Product>>(products,HttpStatus.OK);
	
	}
	
	@GetMapping("/productName/{name}")
	public ResponseEntity<List<Product>> getProductsByName(@PathVariable("name") final String name){
		
		producerTemplate.start();
		@SuppressWarnings("unchecked")
		List<Product> products = producerTemplate.requestBody("direct:fetchProductsName", name, List.class);
	    System.out.println("products "+products);
		producerTemplate.stop();
		return new ResponseEntity<List<Product>>(products,HttpStatus.OK);
	
	}
	
	@PostMapping("/order/genOrder")
	public ResponseEntity<Order> genOrder(@RequestBody OrderRequest req) throws Exception, JsonProcessingException{
		
		producerTemplate.start();
		System.out.println("genOrder Req= "+req);
		@SuppressWarnings("unchecked")
		Order order = producerTemplate.requestBody("direct:genOrder",req, Order.class);
	    System.out.println("order "+order.toString());
		producerTemplate.stop();
		return new ResponseEntity<Order>(order,HttpStatus.OK);
	
	}
	
	
	@PostMapping("/products/generateOrder")
    public ResponseEntity<?> generateOrder(@RequestBody OrderRequest req) throws JMSException,Exception{
		 
		Order res= orderService.generateOrder(req);
		return new ResponseEntity<Order> (res,HttpStatus.OK);
    }
	
	@PostMapping("/products/getPrice")
    public ResponseEntity<? extends List> getPrice(@RequestBody String req) throws JMSException,Exception{
		 
		List<Product> res= orderService.getPrice(req);
		return new ResponseEntity<List<Product>> (res,HttpStatus.OK);
    }
	
	
	@PostMapping("/products/getOrders")
    public ResponseEntity<?> getOrder() throws JMSException,Exception{
		 
		List<Order> res= orderService.getOrders();
		return new ResponseEntity<List<Order>> (res,HttpStatus.OK);
    }
	
	
	@GetMapping("/products/sendMessage/{id}")
    public ResponseEntity<?> indexProduct(@PathVariable String id) throws JMSException,Exception{
		 
		/*if(id.equals("1")) {
			throw new ResourceNotFoundException("Not data Found");
		}*/
		ResponseType res=null;
		  res= productService.sendMessage(id);
		return new ResponseEntity<String> (res.getMessage(),HttpStatus.OK);
    }
	
	
	@GetMapping("/products/sendMessageKafka/{id}")
	@ResponseBody
    public ResponseEntity<?> indexProductKafka(@PathVariable String id) throws Exception{
        productService.sendMessageKafka(id);
        return new ResponseEntity<String>(id,HttpStatus.OK);
    }

}
