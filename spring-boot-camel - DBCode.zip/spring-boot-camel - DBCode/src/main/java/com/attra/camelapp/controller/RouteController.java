/**
 * 
 */
package com.attra.camelapp.controller;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestBindingMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.attra.camelapp.models.Order;
import com.attra.camelapp.models.ResponseType;
import com.attra.camelapp.request.OrderRequest;
import com.attra.camelapp.services.OrderService;

/**
 * @author sushantrane
 *
 */
@Component
//@Profile({"!default && swagger"})
public class RouteController  extends RouteBuilder {
	
	@Autowired
	private Environment env;

	@Override
	public void configure() throws Exception {
		//CamelContext context = new DefaultCamelContext();
	    String contextPath = env.getProperty("camel.servlet.mapping.context-path", "/camel");

		
		restConfiguration()
        .contextPath("/ecommapp")
        .apiContextPath("/api-doc")
        .apiProperty("api.title", "order app")
        .apiProperty("api.version", "1.0")
        .apiProperty("cors", "true")
        .apiContextRouteId("doc-api")
        .port(env.getProperty("server.port", "8080"))
        .bindingMode(RestBindingMode.json);
		
		rest("/order/process").consumes(MediaType.APPLICATION_JSON_VALUE)
		.post("/").description("This api is used to fetch order Process")
		 .produces(MediaType.APPLICATION_JSON_VALUE)
		.route().routeId("orders-api")
		.setBody().body(OrderRequest.class)
		.bean(OrderService.class, "generateOrder")
		.outputType(Order.class)
		//.to("direct:fetchProcess")
		.endRest();
		
		rest("/product/process")
		.get("{id}").description("Process product")
		 .produces(MediaType.APPLICATION_JSON_VALUE)
		.route().routeId("exception-route")
		.outputType(ResponseType.class)
		.tracing()
		// .onException(CamelCustomException.class)
		.to("bean:productService?method=sendMessage(${header.id})")
	   // .to("jms:attra-activemq-queue")
		.endRest();
		
		rest("/product/sendMessage")
		.get("{id}").description("Process product")
		 .produces(MediaType.APPLICATION_JSON_VALUE)
		.route().routeId("send-message-activemq")
		.outputType(ResponseType.class)
		.tracing()
		// .onException(CamelCustomException.class)
		.to("bean:productService?method=sendMessageKafka(${header.id})")
	   // .to("jms:attra-activemq-queue")
		.endRest();
		
		
		/*onException(Exception.class).process(new Processor() {

            public void process(Exchange exchange) throws Exception {
                System.out.println("handling ex");
                throw new Exception("test ex");
            }
        }).log("Received body ").handled(true);*/
		
		
		/*
		 * rest("/orders/") .id("api-route") .consumes("application/json")
		 * .post("/bean") .bindingMode(RestBindingMode.json_xml) .type(Order.class)
		 * .to("direct:remoteService");
		 */
		
	}

}
