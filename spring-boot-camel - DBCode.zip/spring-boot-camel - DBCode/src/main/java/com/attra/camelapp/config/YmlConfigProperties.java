package com.attra.camelapp.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "yaml")
public class YmlConfigProperties {

    private Mq mq;
    
    

    public Mq getMq() {
        return mq;
    }
    public void setMq(Mq mq) {
        this.mq = mq;
    }

    public class Mq {
        private String broker;

        public String getBroker() {
            return broker;
        }

        public void setBroker(String broker) {
            this.broker = broker;
        }
    }    
}