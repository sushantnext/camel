package com.attra.camelapp;

import java.util.Random;
import java.util.Scanner;

/**
 * The constant data utility used in this Demo
 * 
 * @author Mary.Zheng
 *
 */
public final class DataUtils {

	public static final int MESSAGE_SIZE = 10;
	public static final String DESTINATION = "test.queue";

	private static final String COMMA = ",";
	private static final String FAILOVER = "failover:(";

	private static final String HALF_MINUTE_TIMEOUT = ")?timeout=30000&maxReconnectAttempts=5&maxReconnectDelay=10000&initialReconnectDelay=10000&startupMaxReconnectAttempts=5";

	private static String STANDALONE_BROKER_1 = "tcp://localhost:61616";
	private static String STANDALONE_BROKER_2 = "tcp://localhost:61716";

	private static String MASTER_BROKER_1 = "tcp://localhost:61816";
	private static String SLAVE_BROKER_2 = "tcp://localhost:61826";

	private static String[] STATIC_NC_BROKER = { "tcp://localhost:61516", MASTER_BROKER_1, SLAVE_BROKER_2 };
	private static String[] DYNAMIC_NC_BROKER = { "tcp://localhost:61616", "tcp://localhost:61716","tcp://localhost:61816" };

	private static String getStaticNCBroker() {	 
		return STATIC_NC_BROKER[0];
	}
	
	public  String getDynamicNCBroker() {
		Random rand = new Random();
		int value = rand.nextInt(3);
		return DYNAMIC_NC_BROKER[value];
	}

	public static String buildDummyMessage(int value) {		 
		return "dummy message " + value;
	}

	public  String getFailOverURI(String... uris) {

		String[] brokerURIs = uris;
		StringBuffer foUrl = new StringBuffer(FAILOVER);

		int brokerUriSize = brokerURIs.length;
		if (brokerUriSize == 1) {
			foUrl.append(brokerURIs[0]);
		} else {
			for (String brokerUri : brokerURIs) {
				foUrl.append(brokerUri);
				if (!brokerUri.equalsIgnoreCase(brokerURIs[brokerUriSize - 1])) {
					foUrl.append(COMMA);
				}
			}
		}

		foUrl.append(HALF_MINUTE_TIMEOUT);// fast fails
		return foUrl.toString();
	}

	public static String readFailoverURL() {
		String promptyMessage = "Enter Demo Type for Failover:"
				+ "\n\t1 - Stand Alone Brokers \n\t2 - Master-Slave Brokers \n\t3 - Network of Brokers(Static) \n\t4 - Network of Brokers(Dynamic): ";
		System.out.println(promptyMessage);
		String failoverUrl = null;

		try (Scanner scanIn = new Scanner(System.in)) {
			String inputString = scanIn.nextLine();
			scanIn.close();
			switch (inputString) {
			case "1":
		//		failoverUrl = DataUtils.getFailOverURI(STANDALONE_BROKER_1, STANDALONE_BROKER_2);
				break;
			case "2":
		//		failoverUrl = DataUtils.getFailOverURI(MASTER_BROKER_1, SLAVE_BROKER_2);
				break;
			case "3":
	//			failoverUrl = DataUtils.getFailOverURI(getStaticNCBroker());
				break;
			case "4":
		//		failoverUrl = DataUtils.getFailOverURI(getDynamicNCBroker());
				break;
			}
		}

		return failoverUrl;
	}

}
